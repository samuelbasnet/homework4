a='python'
print(a[:])  #sabai print huncha
a='python'
print(a[::]) ##sabai print huncha
print(a[:-4:-1])