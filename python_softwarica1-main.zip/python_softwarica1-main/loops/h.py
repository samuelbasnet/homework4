# 4.Write a program to print each item in a list of fruits: ["apple", "banana", "cherry"].

fruits=['apple','banana','cherry']
for i in fruits:
    print(i,end="->")