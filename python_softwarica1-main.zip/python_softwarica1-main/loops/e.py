a=int(input("Enter a number:"))
for i in range(10,0,-1):
    print(f"{a}X{i}={a*i}")