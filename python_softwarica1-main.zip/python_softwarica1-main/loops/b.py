a='Softwarica'
for i in range(len(a)-1,-1,-1):
    print(a[i])
