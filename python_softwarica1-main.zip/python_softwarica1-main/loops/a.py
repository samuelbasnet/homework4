a='Softwarica'
for i in a:
    print(i)