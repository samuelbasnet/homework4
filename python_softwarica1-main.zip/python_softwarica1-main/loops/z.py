# 34. Use else block to display a message “Done” after successful execution of for loop.

for i in range(10):
    print(i)
else:
    print('Done')