# 7. Write a forloop statement to print the following series:
# 105 98 -------7

for i in range(105,6,-7):
    print(i)
