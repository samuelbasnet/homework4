a="Softwarica"
for i in range(0,len(a)):
    print(f"{a[i]}={i}")
    