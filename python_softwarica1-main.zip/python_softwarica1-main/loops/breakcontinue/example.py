a=[1,2,3,4,5]
for i in a:
    if(i==3):
        continue
    print(i)
else:
    print('Goodluck')