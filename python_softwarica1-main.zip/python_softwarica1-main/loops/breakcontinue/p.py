# 19. Print multiplication table of  1,2,3,4,5,6,7,8 

for i in range(1,9):
    for j in range(1,11):
        print(f'{i}X{j}={i*j}')
    print("\n\n")