# 3. print each character using indexing

a='Samriddha'
for i in range(0,len(a)):
    print(a[i])
    