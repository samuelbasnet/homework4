# 25. reverse of a string a="programming". 

a='programming'
print("Reversed is:",end="")
for i in range(len(a)-1,-1,-1):
    print(a[i],end="")
