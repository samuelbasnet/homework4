# 12. Given list is [1,2,3,4,5] separate the elements into odd and even categories.

