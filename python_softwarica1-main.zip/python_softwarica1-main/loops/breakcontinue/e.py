# 5. multiplication of a each element. given list=[4,5,3,2]

list=[4,5,3,2]
pro=1
for i in list:
    pro*=i

print(pro)