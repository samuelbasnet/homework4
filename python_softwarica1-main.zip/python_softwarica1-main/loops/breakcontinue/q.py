# 21. Python program to calculate the sum of all the odd numbers within the given range.

range1=50
sum=0
for i in range(1,range1,2):
    sum+=i

print(sum)
