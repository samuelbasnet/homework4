# 26. Place a break statement in the for loop so that it prints from 0 to 7 only (including 7). Given range(50)

for i in range(50):
    if(i<=7):
        print(i)
    else:
        break