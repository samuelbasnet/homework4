# 1. print "softwarica" 10 times 

for i in range(10):
    print('Softwarica')
    