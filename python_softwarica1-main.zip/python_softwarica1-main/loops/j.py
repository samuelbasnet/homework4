# .Write for loop statement to print the following series:
# 10 20 30 --------300

for i in range(10,101,10):
    print(i)
