# 21. Write a program to print the cube of numbers from 1 to 5.

for i in range(1,6):
    print(i**3)