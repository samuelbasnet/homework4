# 20. Write a program to print the square of numbers from 1 to 10.

for i in range(1,11):
    print(i**2)