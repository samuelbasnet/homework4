# 10. Write a python program that return the number of characters in a string. 
# myList = "Parameter"

myList='Nepal'
count=0
for i in myList:
    count=count+1
print("Number of characters are:",count)