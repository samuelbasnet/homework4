a=[1,2,3,4]
sum=0
pro=1
for i in a:
    sum+=i
    pro*=i

print("Sum is:",sum)
print("Product is:",pro)