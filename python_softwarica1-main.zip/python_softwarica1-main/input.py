a=input("Enter something:")
#we know, input function le string ma store gardincha

a=int(input("Enter a number"))
#aba we know ki hamle type casting garyam so aba int bho
a=eval(input("Enter something"))
#aba eval le chai j hamle enter garcham tesai ko data type store garcha. 
#list enter garyo bhane a ko type list huncha. 
