# # # # a='python'
# # # # b=a.maketrans('pxk','wxk')
# # # # print(b)
# # # # print(a.translate(b))


# # # a='python'
# # # # print(a.ljust(7,'*'))
# # # # print(a.rjust(7,'*'))
# # # print(a.zfill(10))  #gives 10-6=4 zeros at left. 


# # # a=' python '
# # # print(a.startswith(' '))

# # a='python'
# # print(a.isalpha())  #if sabai elements is alphabets, gives true. 


# a='python'
# print(a[:3])

a='python'
b=a.maketrans('z','1')
print(b)
