# a='ram'
# b=10.11
# print('python is {} and {}'.format(a,b))  #this works
# print('python is {}'.format(a,b))  #this works
# print('python is {} and {}'.format(a)) #this does not work
# print('python is {1} and {0}'.format(a,b)) #this works
# print('python is {1} and {}'.format(a,b)) #this does not work

