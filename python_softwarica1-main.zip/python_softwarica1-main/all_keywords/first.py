import keyword as ks

print(ks.kwlist)  #gives all keywords in Python in the form of a list 
print(len(ks.kwlist)) #gives the length of the list
print(ks.iskeyword('true')) #returns true if entered word is keyword in python and false if vice versa
print(ks.iskeyword('False'))
print("Hello World")
