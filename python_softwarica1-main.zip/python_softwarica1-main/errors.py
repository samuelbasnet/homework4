# a=[1,2,3]
# print(a[4]) #runtime error

# PRINT("Hello Wolrd") #compile time error

a='10'
b=10
print(a+b)
