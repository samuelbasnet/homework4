print("Hello World")
print("Good Morning!")
