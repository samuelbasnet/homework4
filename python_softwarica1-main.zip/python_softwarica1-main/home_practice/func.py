def func():
    print("Hello World!")

func()