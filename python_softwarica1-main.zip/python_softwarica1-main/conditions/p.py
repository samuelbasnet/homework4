a="Pizza"
dict={
    "Pizza":"$10",
    "Burger":"$7",
    "Pasta":"$8"
}
print(dict[a])