user_name="admin"
password="password123"
if(user_name=='admin' and password=="password123"):
    print("Access Granted")
else:
    print("Access Denied")