a=20
if(a%5==0):
    print("Hello")
else:
    print("Bye")