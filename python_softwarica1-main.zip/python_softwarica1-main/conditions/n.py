age=19
exp=2
if(age>18 and exp>=2):
    print("Eligible")
else:
    print("Not eligible")