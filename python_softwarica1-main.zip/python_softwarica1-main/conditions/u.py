import numpy as np
a=np.arange(1,101)
num=101
if(num in a):
    print("Yes")
else:
    print('NO')