n = int(input("Enter a number: "))

if n % 2 == 0 and n % 3 == 0:
    print("The number is divisible by both 2 and 3.")
else:
    print("The number is not divisible by both 2")