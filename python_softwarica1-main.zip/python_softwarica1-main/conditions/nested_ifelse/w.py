a=3
b=4
if(a!=b):
    if(a>b):
        print(f"{a} is greater than {b}")
    else:
        print(f"{b} is greater than {a}")
else:
    if(a>0):
        print("Positive numbers")
    elif(a<0):
        print("Negative numbers")
    else:
        print("Zero numbers")