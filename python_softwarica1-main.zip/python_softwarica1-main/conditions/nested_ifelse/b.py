a=10
b=20
a=a^b
b=a^b
a=a^b
print("After swapping: a={} and b={}".format(a,b))
