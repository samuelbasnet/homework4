n=4
k=12
print("Each student gets",int(k/n),"apples")
if(k%n==0):
    print("Remaining apples in the basket=0")
else:
    print(f"Remaining apples in the basket={k%n}")