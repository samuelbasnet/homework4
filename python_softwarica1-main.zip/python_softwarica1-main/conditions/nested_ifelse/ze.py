price=int(input("Enter price:"))
if(price>=500 and price<1000):
    print(f"Price after discount:{price-0.05*price}")
else:
    price(f"Price after discount:{price-0.1*price}")