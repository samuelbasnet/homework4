color = input("Enter a color (Red, Yellow, Green): ").capitalize()

if color == "Red":
    print("Stop")
elif color == "Yellow":
    print("Slow Down")
elif color == "Green":
    print("Go")
else:
    print("Invalid Signal")
