r = float(input("Enter the radius of the circle: "))
area=3.14*(r**2)
print(area)