salary = int(input("Enter the employee's monthly salary: "))

if salary > 50000:
    print("High Earner")
elif salary > 20000:
    print("Mid Earner")
else:
    print("Low Earner")
