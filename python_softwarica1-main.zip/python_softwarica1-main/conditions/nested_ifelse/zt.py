number=input("Enter a number:")
if(number>100):
    print("Big number")
elif(number>=50 and number<=100):
    print("Medium number")
else:
    print("Small number")
    