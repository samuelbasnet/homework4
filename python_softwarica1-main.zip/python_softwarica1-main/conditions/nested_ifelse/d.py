x=int(input("Enter a number:"))
if(x>0):
    print("Positive")
elif(x<0):
    print("Negative")
else:
    print("Zero")