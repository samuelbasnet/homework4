marks = float(input("Enter the student's marks: "))

if marks > 50:
    if marks > 90:
        print("Excellent")
    else:
        print("Good")
else:
    print("Fail")
