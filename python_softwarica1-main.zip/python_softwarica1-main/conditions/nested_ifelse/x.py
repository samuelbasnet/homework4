sub_score=85
if(sub_score>90):
    print("Congratulations")
elif(sub_score>=50 and sub_score<=90):
    print("Improvement suggested")
else:
    print("Defer to another course")