#conditional bata 6 marks ko question aaucha. 
a=2
b=3
if (a==b):
    print("1")
elif(a>b):
    print("2")
else:
    print("3")

