height=6
if(height>=6):
    print("Selected")
else:
    print("Not selected")