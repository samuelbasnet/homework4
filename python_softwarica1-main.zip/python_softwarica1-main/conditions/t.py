sal=50001
cr_score=701
if(sal>=50000 and cr_score>=700):
    print("Eligible")
else:
    print("Not eligible")