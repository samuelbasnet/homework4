dict={
    "Red":"Stop",
    "Yellow":"Get Ready",
    "Green":"Go"
}
str="Yellow"
print(dict[str])