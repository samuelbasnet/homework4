a=eval(input("Enter a number:"))
if(a%2==0):
    print("Even number")
else:
    print("Odd number")

