str='PYTHOn'
if(str.isupper()):
    print("Upper cased string")
elif(str.islower()):
    print("Lower cased string")
elif(str.isdigit()):
    print("Digit based string")